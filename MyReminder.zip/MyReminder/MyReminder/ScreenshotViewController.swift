//
//  ScreenshotViewController.swift
//  MyReminder
//
//  Created by Shubham Shinde on 08/06/20.
//  Copyright © 2020 Shubham Shinde. All rights reserved.
//

import UIKit

var image:UIImage = UIImage()

class ScreenshotViewController: UIViewController {
    
    @IBOutlet weak var screenshotImage: UIImageView!
    
    override func viewDidLoad() {
        screenshotImage.image = image
        super.viewDidLoad()

        
    }
    
    @IBAction func saveBtn(_ sender: UIButton) {
        UIImageWriteToSavedPhotosAlbum(screenshotImage.image!, nil, nil, nil)
        
        let alert = UIAlertController(title: "Saved", message: "Your image has been saved", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
        alert.addAction(okAction)
        self.present(alert, animated: true, completion: nil)
    }

}
