//
//  Reminder+CoreDataClass.swift
//  MyReminder
//
//  Created by Shubham Shinde on 07/06/20.
//  Copyright © 2020 Shubham Shinde. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Reminder)
public class Reminder: NSManagedObject {

}
