//
//  Reminder+CoreDataProperties.swift
//  MyReminder
//
//  Created by Shubham Shinde on 07/06/20.
//  Copyright © 2020 Shubham Shinde. All rights reserved.
//
//

import Foundation
import CoreData


extension Reminder {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Reminder> {
        return NSFetchRequest<Reminder>(entityName: "Reminder")
    }

    @NSManaged public var reminder: String?
    @NSManaged public var date: String?

}
