//
//  DatabaseHelper.swift
//  MyReminder
//
//  Created by Shubham Shinde on 08/06/20.
//  Copyright © 2020 Shubham Shinde. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class DatabaseHelper {
    
    static var shareInstance = DatabaseHelper()
    
    let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    
    func save(object:[String:String]) {
        let reminder = NSEntityDescription.insertNewObject(forEntityName: "Reminder", into: context!) as! Reminder
        reminder.reminder = object["reminder"]
        reminder.date = object["date"]
        
        do{
            try context?.save()
        }
        catch{
            print("Reminder is not saved")
        }
    }
    
    func getReminderData() -> [Reminder] {
        var reminder = [Reminder]()
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Reminder")
        do{
            reminder = try context?.fetch(fetchRequest) as! [Reminder]
        }
        catch{
            print("can not get data")
        }
        return reminder
    }
    
    func deleteData(index:Int) -> [Reminder]{
        var reminder = getReminderData()
         context?.delete(reminder[index])
        reminder.remove(at: index)
        do{
            try context?.save()
        }
        catch{
            print("can not delete data")
        }
        return reminder
    }
    
    func editData(object: [String : String], i: Int){
        let reminder = getReminderData()
        reminder[i].reminder = object["reminder"]
        reminder[i].date = object["date"]
        do{
            try context?.save()
        }
        catch{
            print("Data is not edit")
        }
    }
}
