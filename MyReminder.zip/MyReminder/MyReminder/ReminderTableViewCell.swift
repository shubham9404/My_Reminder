//
//  ReminderTableViewCell.swift
//  MyReminder
//
//  Created by Shubham Shinde on 08/06/20.
//  Copyright © 2020 Shubham Shinde. All rights reserved.
//

import UIKit

class ReminderTableViewCell: UITableViewCell {

    @IBOutlet weak var reminderLable: UILabel!
    
    @IBOutlet weak var dateLable: UILabel!
    
    var reminder:Reminder!{
        didSet{
            reminderLable.text = reminder.reminder
            dateLable.text = reminder.date
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
