//
//  SetReminderViewController.swift
//  MyReminder
//
//  Created by Shubham Shinde on 08/06/20.
//  Copyright © 2020 Shubham Shinde. All rights reserved.
//

import UIKit
import UserNotifications

class SetReminderViewController: UIViewController, DataPass {
   
    
    var gameTimer: Timer?
    
    @IBOutlet weak var reminderTextField: UITextField!
    @IBOutlet weak var dateTextField: UITextField!
    @IBOutlet weak var editBtnOutlet: UIButton!
    @IBOutlet weak var savebtnOutlet: UIButton!
    @IBOutlet weak var homeBtnOutlet: UIButton!
    
    @objc private var dateTime: UIDatePicker!

    var i = Int()
    
    var isUpdate = Bool()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        editBtnOutlet.layer.cornerRadius = 10.0
        savebtnOutlet.layer.cornerRadius = 10.0
        homeBtnOutlet.layer.cornerRadius = 10.0
        
        dateTime = UIDatePicker()
        dateTime.datePickerMode = .dateAndTime
        dateTextField.inputView = dateTime
        dateTime.addTarget(self, action: #selector(SetReminderViewController.dateChanged(datePicker:)), for: .valueChanged)
        let tapGesture =  UITapGestureRecognizer(target: self, action: #selector(SetReminderViewController.viewTapped(gestureRecognizer:)))
        view.addGestureRecognizer(tapGesture)
        
    }
    
   

    @objc func dateChanged(datePicker: UIDatePicker){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy @ HH:mm"
        dateTextField.text = dateFormatter.string(from: datePicker.date)
        view.endEditing(true)
    }
    
    @objc func viewTapped(gestureRecognizer:UITapGestureRecognizer){
        view.endEditing(true)
    }

    @IBAction func editBtn(_ sender: UIButton) {
        let srvc = storyboard?.instantiateViewController(withIdentifier: "EditViewController") as! EditViewController
        srvc.reminder = reminderTextField.text!
        srvc.date = dateTextField.text!
        
        
        if(srvc.reminder.isEmpty || srvc.date.isEmpty)
        {
            let myalert = UIAlertController(title: "Alert", message: "write the reminder and select the date", preferredStyle: .alert)
            let okAction = UIAlertAction(title: "Ok", style: .default, handler: nil)
            myalert.addAction(okAction)
            self.present(myalert, animated: true, completion: nil)
        }
        navigationController?.pushViewController(srvc, animated: true)
    }
    
    @IBAction func saveBtn(_ sender: UIButton) {
        let dict = ["reminder":reminderTextField.text, "date":dateTextField.text]
        if isUpdate{
            DatabaseHelper.shareInstance.editData(object: dict as! [String:String], i: i)
        }
        else{
            DatabaseHelper.shareInstance.save(object: dict as! [String:String])
        }
        setReminder()
    }
    
    @IBAction func homeBtn(_ sender: UIButton) {
        let first = navigationController?.viewControllers[0] as! ViewController
        first.delegate = self
        navigationController?.popToViewController(first, animated: true)
    }

    @objc func data(object: [String : String], index: Int, isEdit: Bool) {
           reminderTextField.text = object["reminder"]
           dateTextField.text = object["date"]
           i = index
           isUpdate = isEdit
       }
    
    func setReminder(){
        let time = self.dateTime.date.timeIntervalSinceNow
            let msg = self.reminderTextField.text!
            UNUserNotificationCenter.current().getNotificationSettings { settings in
                if settings.authorizationStatus == UNAuthorizationStatus.authorized{
                    if time > 0{
                        let nContent = UNMutableNotificationContent()
                        nContent.body = msg
                        nContent.title = "Reminder"
                        nContent.sound = UNNotificationSound.default
                        
                        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: time, repeats: false)
                        
                        let request = UNNotificationRequest(identifier: "reminder", content: nContent, trigger: trigger)
                        
                        
                        UNUserNotificationCenter.current().add(request) { (_) in
                            DispatchQueue.main.async {
                                let alert = UIAlertController(title: "Success", message: "Notification is register", preferredStyle: .alert)
                                let ok = UIAlertAction(title: "Ok", style: .default)
                                alert.addAction(ok)
                                self.present(alert, animated: false)
                            }
                        }
                    }
                    else{
                        DispatchQueue.main.async {
                            let alert = UIAlertController(title: "Fail", message: "Notification is not register", preferredStyle: .alert)
                            let ok = UIAlertAction(title: "Ok", style: .default)
                            alert.addAction(ok)
                            self.present(alert, animated: false)
                        }
                    }
                }
                else{
                    DispatchQueue.main.async {
                        let alert = UIAlertController(title: "Fail", message: "You don't allow notifications", preferredStyle: .alert)
                        let ok = UIAlertAction(title: "Ok", style: .default)
                        alert.addAction(ok)
                        self.present(alert, animated: false)
                    }
                }
            }
        }
    }

