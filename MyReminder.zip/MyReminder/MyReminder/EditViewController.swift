//
//  EditViewController.swift
//  MyReminder
//
//  Created by Shubham Shinde on 08/06/20.
//  Copyright © 2020 Shubham Shinde. All rights reserved.
//

import UIKit

class EditViewController: UIViewController {

   var reminder = String()
        var date = String()
        
        @IBOutlet weak var reminderTextView: UITextView!
        
        @IBOutlet weak var sliderOutlet: UISlider!
        
        @IBOutlet weak var screenshotBtnOutlet: UIButton!
        
        override func viewDidLoad() {
            reminderTextView.text = reminder + "\n" + date
            screenshotBtnOutlet.isHidden = false
            super.viewDidLoad()

            
        }
        
        @IBAction func slidervalue(_ sender: UISlider) {
            print(sender.value)
            reminderTextView.font = reminderTextView.font?.withSize(CGFloat(Int(sender.value)))
        }
        
        
        @IBAction func screenshotBtn(_ sender: UIButton) {
            let nextp = storyboard?.instantiateViewController(withIdentifier: "ScreenshotViewController") as! ScreenshotViewController
            let screenshot = self.view.takeScreenshot()
             image = screenshot
            navigationController?.pushViewController(nextp, animated: true)
        }
        
    }

    extension UIView {

    func takeScreenshot() -> UIImage {
        
        //begin
        UIGraphicsBeginImageContextWithOptions(self.bounds.size, false, UIScreen.main.scale)
        
        // draw view in that context.
        drawHierarchy(in: self.bounds, afterScreenUpdates: true)
        
        // get iamge
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        if image != nil {
            return image!
        }
        
        return UIImage()
        
    }
        
      func applying(_ otherConfiguration: UIImage.Configuration?) -> Self
      {
        return self
    }
    

    

}
